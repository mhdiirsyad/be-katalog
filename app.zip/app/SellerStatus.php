<?php

namespace App;

enum SellerStatus
{
    case PENDING;
    case ACTIVE;
    case REJECTED;
}
